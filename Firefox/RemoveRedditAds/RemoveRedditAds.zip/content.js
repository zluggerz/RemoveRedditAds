$( ".promoted" ).remove();
$(".premium-banner").remove();

console.log("Hidden Ads Removed");